function [VarSI,ESsqI,ESI]=VarSFun2(M,k)
%%% The information matrix argument given here is not invertible;
%%%
%%% Calculation of Var(s) value.
    
    ESsqI=sum(sum(triu(M,1).^2))/((k*(k+1))/2);
	ESI=sum(sum(triu(M,1)))/((k*(k+1))/2);

	VarSI=ESsqI-(ESI)^2;
end