function [ESsqI]=ESsqFun(M,k)
%%% The information matrix argument given here is not invertible;
%%%
%%% Calculation of E(s^2) value

    ESsqI=sum(sum(triu(M,1).^2))/((k*(k+1))/2);

    
end