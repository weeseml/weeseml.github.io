%%% Code to accompany 
%%%
%%% "Powerful Supersaturated Designs when Effect Directions are Known"
%%%
%%% by M.L. Weese, D.J. Edwards, and B.J. Smucker.

%%% Front-end code for a k-factor, n-run supersaturated design. This
%%% calls functions that invoke a coordinate exchange algorithm to find  
%%% constrained positive Var(s)-optimal designs.

%%% Though there is an option that allows E(s) to be negative on average,
%%% this is not recommended. The resulting designs will not have elevated
%%% power to detect active effects, as the constrained positive Var(s)
%%% designs do. There is also an option that allows a constrained E(s)
%%% criterion instead of constrained Var(s). Similar power results will be
%%% realized for either criterion, though we have focused on Var(s) in the
%%% article.

clear all;

% define whether we want E(s) to be positive ('pos') or negative ('neg')
ESSigns={'pos'};
% define the criterion to be either constrained Var(s) 'vars' or 
% constrained E(s) 'es'
Crits={'vars'};

% Defines the experiments to be constructed; i.e. the first element in Ns
% and the first elements in ks will define one experiment; the second in
% each will define the second; etc.
%Ns=[6,6,8,10,10,12,14,14,16,18];
%ks=[7,10,12,11,15,26,23,24,30,22];
Ns=5;
ks=10;

for jj=1:length(Crits)
    Crit=Crits{jj};
    Crits{jj}
    for kk=1:length(ESSigns)
        ESSign=ESSigns{kk};
        ESSigns{kk}
        for ii=1:length(Ns)
            N=Ns(ii);
            NumFactors=ks(ii);
            N
            NumFactors
            % During the coordinate-by-coordinate search, this is the 
            % the resolution to which the search will be conducted, for 
            % each factor
            GridRes=2*ones(1,NumFactors);
            NumRuns=100;     % number of random starts
            % couple of algorithm parameters; shouldn't be changed, typically.
            iter=20*(N+1);
            eps=0.0001;
            % ESsq-efficiency that we require
            ESsqEffReqs=[0.8];

            %%% Read in a file that includes just the design of interest. 
            %%% Note that the format of the name of the file must be specified below.
            infile=sprintf('n%d_k%d_ESsq_unbalanced_withIntercept_100_just_design.txt',N,NumFactors);

            % read in file
            fileID = fopen(infile);

            formatSpec=repmat('%f',1,NumFactors);
            infile_read = textscan(fileID,formatSpec,'CollectOutput',1);

            fclose(fileID);

            DESsqUnOpt=infile_read{1,1};

            kNum=N;

            % define the lower and upper bounds for each factor individually
            IndConstr=horzcat(-1*ones(NumFactors,1),1*ones(NumFactors,1));

            % Here is a cell array with the grid for each coordinate group (aka each
            % coordinate, since we don't have coordinate group capability now)
            CoordGrids=cell(1,NumFactors);
            for i=1:NumFactors
                CoordGrids{i}=IndConstr(i,1):GridRes(i):IndConstr(i,2);
            end

            % define the main effects + intercept model
            % each row represents a different term in the full model. For instance, a
            % row that had a 1 in the first spot and 0s in the other 22 columns
            % represents the main effect for factor 1.
            model=vertcat(zeros(1,NumFactors),eye(NumFactors,NumFactors));
            NumPars=size(model,1);

            % Get ESsq-value for unbalanced ES-sq optimal design
            MESsqUnOpt=InfoMatFun(DESsqUnOpt,model);
            ESsqUnOpt=ESsqFun(MESsqUnOpt,NumFactors);

            for aa=1:length(ESsqEffReqs)

                ESsqEffReq=ESsqEffReqs(aa);

                % Now this will be a loop, each iteration being a run of 
                % the algorithm with a particular initial design

                tic;

                NumIters=zeros(1,NumRuns);  % gives the number of iterations for each run
                InitialDesigns=zeros(NumFactors,N,NumRuns); % gives the initial design for each run
                OptDesigns=zeros(NumFactors,N,NumRuns); % gives the "optimal" design for each run
                OptVarSs=zeros(NumRuns,1); % gives the Var(s) values for the optimal design for each run  
                ESs=zeros(NumRuns,1);
                FinalESsqEffs=zeros(NumRuns,1); % gives the final ES-sq efficiencies for the design we end up with    

                for j=1:NumRuns

                    fprintf('Run Number for supersaturated design %d\n',j)

                    % Initial design: Generate feasible, random
                    % points coordinate-by-coordinate
                    [DInit,ESInit]=DInitFun_CX_Random_VarS(N,NumFactors,CoordGrids,model,ESSign);

                    if strcmp(Crit,'vars')==1
                        [i,DCurr,VarS,ES,ESsqEff]=mainVarS(NumFactors,kNum,model,iter,eps,DInit,ESsqUnOpt,ESsqEffReq,CoordGrids,ESSign);
                    elseif strcmp(Crit,'es')==1
                        [i,DCurr,VarS,ES,ESsqEff]=mainES(NumFactors,kNum,model,iter,eps,DInit,ESsqUnOpt,ESsqEffReq,CoordGrids,ESSign);
                    end

                    NumIters(1,j)=i;
                    InitialDesigns(:,:,j)=DInit';
                    OptDesigns(:,:,j)=DCurr';
                    OptVarSs(j)=VarS;
                    ESs(j)=ES;
                    FinalESsqEffs(j)=ESsqEff;

                    %min(OptVarSs(OptVarSs > 0))

                end;

                tElapsed=toc/60;

                if strcmp(Crit,'vars')==1
                    [BestVarS,BestRun]=min(OptVarSs);
                    ESforBest=ESs(BestRun);
                    BestDesign=OptDesigns(:,:,BestRun)';
                    FinalESsqEffBestDesign=FinalESsqEffs(BestRun);

                    BestVarS
                    ESforBest
                elseif strcmp(Crit,'es')==1 && strcmp(ESSign,'pos')==1
                    [BestES,BestRun]=max(ESs);
                    VarSforBest=OptVarSs(BestRun);
                    BestDesign=OptDesigns(:,:,BestRun)';
                    FinalESsqEffBestDesign=FinalESsqEffs(BestRun);

                    BestES
                    VarSforBest
                elseif strcmp(Crit,'es')==1 && strcmp(ESSign,'neg')==1
                    [BestES,BestRun]=min(ESs);
                    VarSforBest=OptVarSs(BestRun);
                    BestDesign=OptDesigns(:,:,BestRun)';
                    FinalESsqEffBestDesign=FinalESsqEffs(BestRun);

                    BestES
                    VarSforBest
                end


                BestDesign
                FinalESsqEffBestDesign

                name=sprintf('n%d_k%d_%s_%s_Eff%d_%d',N,NumFactors,Crit,ESSign,ESsqEffReq*100,NumRuns);

                % save all variables currently in the Matlab environment
                %   * filename will be according to the name indicated
                %   above
                %   * use the command 'load <name>' to bring them back in
                %   * if you don't want any previously existing variables saved
                %        as well, use 'clear all' before calling this script
                save(name)    

                % output a text file with just BestDesign

                outfile=sprintf('n%d_k%d_%s_%s_Eff%d_%d.txt',N,NumFactors,Crit,ESSign,ESsqEffReq*100,NumRuns);

                fileID2=fopen(outfile,'wt');

                    formatSpec2=[repmat('%d\t',1,NumFactors),'\n'];
                    fprintf(fileID2,formatSpec2,BestDesign');

                fclose(fileID2);

            end
        end
    end
end