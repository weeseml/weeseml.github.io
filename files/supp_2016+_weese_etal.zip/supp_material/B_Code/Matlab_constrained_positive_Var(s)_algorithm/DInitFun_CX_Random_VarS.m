function [DInitBest,ES]=DInitFun_CX_Random_VarS(N,NumFactors,CoordGrids,model,ESSign)
%%% this is a function which, without a candidate list, constructs an initial
%%% design randomly, coordinate-by-coordinate.

    if strcmp(ESSign,'pos') % if we want E(s) positive, start with ES neg
        ES=-1e10;
    elseif strcmp(ESSign,'neg') 
        ES=1e10;
    end
    
    flag=0;
        
    while flag==0
        DInit=zeros(N,NumFactors);

        for k=1:N
            for l=1:NumFactors
                DInit(k,l)=randsample(CoordGrids{l},1,false); 
            end                
        end
        [MInit,~]=InfoMatFun(DInit,model);
        
        % get unbalanced Var(s) and E(s) 
        [~,~,ES]=VarSFun2(MInit,NumFactors);

        if strcmp(ESSign,'pos')==1
            if ES > 0 % if we want ES positive, stop when we get ES positive
                DInitBest=DInit;
                flag=1;
            end
        else 
            if ES < 0
                DInitBest=DInit;
                flag=1;
            end
        end
        if ES > 0
            DInitBest=DInit;
        end
        
    end
             
end

