function [Ex,NewCoord,VarSNew,ESNew,MCurr]=ConstrVarSOptFun2(xi,xij,m,MCurr,VarS,ES,NumFactors,ESsqUnOpt,ESsqEffReq,ESSign)
% Function which takes a current coordinate in the design (xij) and finds the
% exchange that will most decrease the Var(s) value, regardless of design
% balance, but constrained by an ES-sq efficiency.

    %%% This will be
    %%% updated as we go through the grid points and find that a potential
    %%% exchange will increase the criterion
    VarSNew=VarS;
    ESNew=ES;
    
    Ex=0; % set this to zero; it will be changed if there is an exchange that results in an improvement
    
    % Since we are considering only two level designs, just multiply the
    % current coordinate by -1
    xtry=xi;
    xtry(m)=xij*(-1);  % 'xtry' is the design point that would result if the m'th coordinate is exchanged
    
    % update quantities of interest
    [ESsqChange,newMm,changes]=ESsqUpdateFun(MCurr,m,xi);
    changes(m+1)=[];
    ESChange=sum(changes)/((NumFactors*(NumFactors+1))/2);
    VarSChange=ESsqChange - (ES+ESChange)^2 + ES^2;
    ESsqEffTry=ESsqUnOpt/(VarS+ES^2+ESsqChange);

    if strcmp(ESSign,'pos')
        if VarSChange < 0 && ESsqEffTry >= ESsqEffReq && ES+ESChange > 0
            VarSNew=VarS+VarSChange;
            ESNew=ES+ESChange;
            MCurr(m+1,:)=newMm;
            MCurr(:,m+1)=newMm';
            Ex=1;
            NewCoord=xtry(m);
        else
            NewCoord=xij;
        end
    elseif strcmp(ESSign,'neg')    
        if VarSChange < 0 && ESsqEffTry >= ESsqEffReq && ES+ESChange < 0
            VarSNew=VarS+VarSChange;
            ESNew=ES+ESChange;
            MCurr(m+1,:)=newMm;
            MCurr(:,m+1)=newMm';
            Ex=1;
            NewCoord=xtry(m);
        else
            NewCoord=xij;
        end
    end    
end