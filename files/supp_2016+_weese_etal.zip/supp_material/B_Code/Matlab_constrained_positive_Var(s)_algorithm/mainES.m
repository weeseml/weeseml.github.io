function [i,DCurr,VarS,ES,ESsqEff]=mainES(NumFactors,kNum,model,iter,eps,DInit,ESsqUnOpt,ESsqEffReq,CoordGrids,ESSign)
    % This is a function that attempts to optimize ES and takes in:
    % NumFactors: the number of factors;
    % kNum: number of design points exchanged each iteration, typically N
    % model: for supersaturated experiments, the model is the intercept
    %  plus main effects
    % NumPars: specifies the number of parameters for the model 
    % CoordGrids is a cell array with a 1-D grid for each coordinate
    % iter: maximum number of iterations
    % eps: epsilon, to set termination criterion
    % DInit: initial design
    % ESsqUnOpt: optimal ES-sq value for unbalanced ES-sq optimal design
    % ESsqEffReq: required ES-sq efficiency
    % CoordGrids: grid of possible values for each factor
    % ESSign: whether the average column correlations are positive or 
    %  negative    
    
    N=size(DInit,1);
    
    % get information matrix; 
    [MInit, ~]=InfoMatFun(DInit,model);
    [~,ESsqInit,ESInit]=VarSFun2(MInit,NumFactors);
    
    DCurr=DInit;
    MCurr=MInit;  % contains info matrices for each of the responses
    ESsqCurr=ESsqInit;
    ESCurr=ESInit;
    
    % First, get the design up to at least the ES-sq efficiency required by
    % ESsqEffReq
    ESsqEffCurr=ESsqUnOpt/ESsqCurr;
    flag=0; % if flag gets too large, generate a new initial design
    while ESsqEffCurr < ESsqEffReq
        flag=flag+1;
        for l=1:N
            
            Index=l;  % determine the index of the point to be considered
			xi=DCurr(Index,:);  % this is the design point whose coordinate we may exchange

            for m=1:NumFactors
                xij=DCurr(Index,m); % this is the coordinate of interest, that we will consider exchanging
                                
                % Consider exchanges with all coordinates in the coordinate
                % grid, and find the one which gives the minimum ES-sq,
                % regardless of design balance.
                [Ex,NewCoord,ESsqCurr,ESCurr,MCurr]=ESsqUnOptFun2(xi,xij,m,MCurr,ESsqCurr,ESCurr,ESSign);

                % If swap is for a new coordinate, update termination
                % criterion variables
                if Ex==1
                    % make swap (even if "swap" is the same coordinate as
                    % before)
                    DCurr(Index,m)=NewCoord;

                    % if we update the design, we need to update xi
           			xi=DCurr(Index,:);  % this is the design point whose coordinate we may exchange
                    
                    ESsqEffCurr=ESsqUnOpt/ESsqCurr;
                    
                    if ESsqEffCurr > ESsqEffReq
                        break;
                    end
                    
                end
       
            end
            
            if ESsqEffCurr > ESsqEffReq
                break;
            end
            
        end
        % if we can't find a good enough design in terms of E(s^2) eff, 
        % construct another initial design
        if flag>9

            [DInit,~]=DInitFun_CX_Random_VarS(N,NumFactors,CoordGrids,model,ESSign);
            DCurr=DInit;
            [MInit, ~]=InfoMatFun(DInit,model);
            [~,ESsqInit,ESInit]=VarSFun2(MInit,NumFactors);

            MCurr=MInit;  % contains info matrices for each of the responses
            ESsqCurr=ESsqInit;
            ESCurr=ESInit;
            % First, get the design up to at least the ES-sq efficiency required by
            % ESsqEffReq
            ESsqEffCurr=ESsqUnOpt/ESsqCurr;

            flag=0; 
        end
    end
    
    % This is the current ES value, that will
    % not get changed except at the end of each iteration
    [VarS,~,ESIter]=VarSFun2(MCurr,NumFactors);
    % This is the current ES value
    ES=ESIter;

    br=0;   % having to do with termination criterion
    
    Term_l=1;
    Term_m=1;
    Term_iter=1;
    
    for i=1:iter
        
        kIndices=1:kNum;

        % for the kNum least critical design points
        for l=1:kNum
            
            Index=kIndices(l);  % determine the index of the point to be considered

			xi=DCurr(Index,:);  % this is the design point whose coordinate we may exchange

            for m=1:NumFactors
                xij=DCurr(Index,m); % this is the coordinate of interest, that we will consider exchanging
                                
                % Consider exchanges with all coordinates in the coordinate
                % grid, and find the one which gives the minimum VarS,
                % regardless of design balance.
                [Ex,NewCoord,VarS,ES,MCurr]=ConstrESOptFun2(xi,xij,m,MCurr,VarS,ES,NumFactors,ESsqUnOpt,ESsqEffReq,ESSign);

                % If swap is for a new coordinate, update termination
                % criterion variables
                if Ex==1
                    % for termination criterion
                    Term_iter=i;
                    Term_l=l;
                    Term_m=m;                    
                    % make swap (even if "swap" is the same coordinate as
                    % before)
                    DCurr(Index,m)=NewCoord;

                    % if we update the design, we need to update xi and vxi
           			xi=DCurr(Index,:);  % this is the design point whose coordinate we may exchange
                    
                end
                                
                % if we have not made an exchange since this time last iteration,
                % set br to 1 and break out of the m loop 
                if Term_l==l && Term_m==m && i==(Term_iter+1)
                    br=1;   
                    break;
                end

            end
            
            if br==1
                break;  % break out of l loop
            end

        end      
           
        if (abs(ES-ESIter) < eps) || (br==1)
            break;
        end
                    
        % This is the current value of the criterion that
        % does not get changed except at the end of each iteration
        ESIter=ES;
        
    end;
    
    [VarS,ESsq,~]=VarSFun2(MCurr,NumFactors);
    ESsqEff=ESsqUnOpt/ESsq;
    
    
end