function [ESsqC,newMm,changes]=ESsqUpdateFun(M,m,xi)
%%% The information matrix argument given here is not invertible;
%%%
%%% Calculate the change in the E(s^2) value. Includes intercept.
%%%
%%% M is the current information matrix; m is the column in the design that
%%% is being considered for an exchange; xi is the row in the current
%%% design whose coordinate m we are considering changing
%%%
%%% ESsqC is the change in ESsq; newMm is the new m^th row/column in M;
%%% changes are the changes for each element

    k=length(xi);

    % If an element is the same sign as the new coordinate, it will change
    % by +2; if it is the opposite sign, it will change by -2; augment xi
    % with 1, for the intercept
    changes=2*(xi(m)*(-1))*[1,xi];
    
    % calculate the new row m+1 (corresponding to element m in the ith row
    % of design) in M; note that the m+1'th entry is bogus.
    newMm=M(m+1,:)+changes;
    newMm(m+1)=M(m+1,m+1); % don't include element (m,m) in calculating the changes
    
    oldMm=M(m+1,:);
    
    % change in E(s^2)
    ESsqC=(sum(newMm.^2)-sum(oldMm.^2))/((k*(k+1))/2);
end
