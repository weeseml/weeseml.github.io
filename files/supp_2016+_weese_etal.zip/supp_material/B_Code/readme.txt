Supplementary material for 

 "Powerful Supersaturated Designs when Effect Directions are Known"

There are two folders, each with Matlab files in them.

Before constrained positive Var(s) designs can be constructed, unbalanced E(s^2) designs of the same size must be constructed. This can be done by placing all of the .m files in the "Matlab_unbalanced_Essq_algorithm" in a folder and open

  "n_k_ESsq_unbalanced_withIntercept.m"

Specify the number of runs (Ns) and number of factors (ks) and copy all code into the Matlab command window. The output will include a text file with the design. 

The text file with the unbalanced E(s^2) design must be placed in the folder along with the .m files in the "Matlab_constrained_positive_Var(s)_algorithm" (either leave the name of the file as is, or make sure it matches with the name in "n_k_VarS-Constr-Int-Pos-Neg.m"). Open

  "n_k_VarS-Constr-Int-Pos-Neg.m"

Specify the number of runs (Ns) and number of factors (ks) and copy all code into the Matlab command window. The output will include a text file with the design.



























