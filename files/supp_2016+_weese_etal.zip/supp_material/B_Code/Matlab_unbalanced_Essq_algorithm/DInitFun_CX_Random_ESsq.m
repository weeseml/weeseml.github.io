function [DInitBest bestESsq]=DInitFun_CX_Random_ESsq(N,NumFactors,CoordGrids,model,NumDInits)
%%% this is a function which, without a candidate list, constructs an initial
%%% design randomly, coordinate-by-coordinate, choosing the best out of
%%% NumDInits in terms of the unbalanced E(s^2).

    bestESsq=1e10;
    
    for i=1:NumDInits
        DInit=zeros(N,NumFactors);

        for k=1:N
            for l=1:NumFactors
                DInit(k,l)=randsample(CoordGrids{l},1,false); 
            end                
        end
        [MInit ~]=InfoMatFun(DInit,model);
        
        % get unbalanced E(s^2) 
        [ESsq]=ESsqFun(MInit,NumFactors);
        
        if ESsq < bestESsq
            bestESsq=ESsq;
            DInitBest=DInit;
        end
    end
         
end

