function [i,DCurr,ESsq]=main(NumFactors,kNum,model,iter,eps,DInit)
    % This is a function that takes in:
    % NumFactors: the number of factors;
    % kNum: number of design points exchanged each iteration, typically N
    % model: for supersaturated experiments, the model is the intercept
    %  plus main effects
    % NumPars: specifies the number of parameters for the model 
    % CoordGrids is a cell array with a 1-D grid for each coordinate
    % iter: maximum number of iterations
    % eps: epsilon, to set termination criterion
    % DInit: initial design
                
    % get information matrix; 
    [MInit, ~]=InfoMatFun(DInit,model);
    [~,ESsqInit,ESInit]=VarSFun2(MInit,NumFactors);
    
    DCurr=DInit;
    MCurr=MInit;  % contains info matrices for each of the responses
    
    % This is the current ESsq value, that will
    % not get changed except at the end of each iteration
    ESsqIter=ESsqInit;
    % This is the current ESsq value
    ESsq=ESsqInit;
    ES=ESInit;

    br=0;   % having to do with termination criterion
    
    Term_l=1;
    Term_m=1;
    Term_iter=1;
    
    for i=1:iter
        
        kIndices=1:kNum;

        % for the kNum least critical design points
        for l=1:kNum
            
            Index=kIndices(l);  % determine the index of the point to be considered

			xi=DCurr(Index,:);  % this is the design point whose coordinate we may exchange

            for m=1:NumFactors
                xij=DCurr(Index,m); % this is the coordinate of interest, that we will consider exchanging
                                
                % Consider exchanges with all coordinates in the coordinate
                % grid, and find the one which gives the minimum ESsq,
                % regardless of design balance.
                [Ex,NewCoord,ESsq,ES,MCurr]=ESsqUnOptFun3(xi,xij,m,MCurr,ESsq,ES);
                
                % If swap is for a new coordinate, update termination
                % criterion variables
                if Ex==1
                    % for termination criterion
                    Term_iter=i;
                    Term_l=l;
                    Term_m=m;                    
                    % make swap (even if "swap" is the same coordinate as
                    % before)
                    DCurr(Index,m)=NewCoord;

                    % if we update the design, we need to update xi and vxi
           			xi=DCurr(Index,:);  % this is the design point whose coordinate we may exchange
                    
                end
                                
                % if we have not made an exchange since this time last iteration,
                % set br to 1 and break out of the m loop 
                if Term_l==l && Term_m==m && i==(Term_iter+1)
                    br=1;   
                    break;
                end

            end
            
            if br==1
                break;  % break out of l loop
            end

        end      
           
        if (abs(ESsq-ESsqIter) < eps) || (br==1)
            break;
        end
                    
        % This is the current value of the criterion that
        % does not get changed except at the end of each iteration
        ESsqIter=ESsq;
        
    end;
   
end