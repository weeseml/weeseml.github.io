function [M X]=InfoMatFun(D,model)

    X=x2fx(D,model);
    M=X'*X;
        
end