function [MNew]=InfoUpdateFun(x,xi,model,M)
%%% xi is a current design point we may exchange
%%% x is a design point that we may swap for xi
%%% This assumes a single model.

    rho_x_tr=x2fx(x,model)';
    rho_xi_tr=x2fx(xi,model)';
    % these matrices are (p_o x 2)
    A=[-rho_xi_tr, rho_x_tr];
    B=[rho_xi_tr,rho_x_tr];
    MNew=M+A*B';

end