%%% Code to accompany 
%%%
%%% "Powerful Supersaturated Designs when Effect Directions are Known"
%%%
%%% by M.L. Weese, D.J. Edwards, and B.J. Smucker.

%%% Front-end code for a k-factor, n-run supersaturated design. This
%%% calls functions that invoke a coordinate exchange algorithm to find a 
%%% design that minimized the E(s^2) criterion, without respecting design 
%%% balance.

clear all;

% Defines the experiments to be constructed; i.e. the first element in Ns
% and the first elements in ks will define one experiment; the second in
% each will define the second; etc.
%Ns=[5,6,7,9,9,16,17,19,20,24,26,31];
%ks=[10,11,8,12,18,26,18,23,34,34,31,33];
Ns=5;
ks=5;

for ii=1:length(Ns)

    N=Ns(ii);
    NumFactors=ks(ii);
    % During the coordinate-by-coordinate search, this is the resolution to
    % which the search will go, for each factor
    GridRes=2*ones(1,NumFactors);
    NumRuns=100;     % number of times to run the algorithm
    % couple of algorithm parameters; shouldn't be changed, typically.
    iter=20*(N+1);
    eps=0.0001;
    NumDInits=10;

    %kNum=max(1,floor(N/4));
    kNum=N;

    % define the lower and upper bounds for each factor individually
    IndConstr=horzcat(-1*ones(NumFactors,1),1*ones(NumFactors,1));

    % Here is a cell array with the grid for each coordinate group (aka each
    % coordinate, since we don't have coordinate group capability now)
    CoordGrids=cell(1,NumFactors);
    for i=1:NumFactors
        CoordGrids{i}=IndConstr(i,1):GridRes(i):IndConstr(i,2);
    end

    % define the main effects + intercept model
    % each row represents a different term in the full model. For instance, a
    % row that had a 1 in the first spot and 0s in the other 22 columns
    % represents the main effect for factor 1.
    model=vertcat(zeros(1,NumFactors),eye(NumFactors,NumFactors));
    NumPars=size(model,1);

    % Now this will be a loop, each iteration being a run of the algorithm with
    % a particular initial design

    tic;

    NumIters=zeros(1,NumRuns);  % gives the number of iterations for each run
    InitialDesigns=zeros(NumFactors,N,NumRuns); % gives the initial design for each run
    ESsqInits=zeros(NumRuns,1);
    OptDesigns=zeros(NumFactors,N,NumRuns); % gives the "optimal" design for each run
    OptESsqs=zeros(NumRuns,1); % gives the power values for the optimal design for each run  

    for j=1:NumRuns

        fprintf('Run Number for supersaturated design %d\n',j)

        % Simpler initial design mechanism: Generate feasible, random
        % points coordinate-by-coordinate
        [DInitBest bestESsq]=DInitFun_CX_Random_ESsq(N,NumFactors,CoordGrids,model,NumDInits);

        [i,DCurr,ESsq]=main(NumFactors,kNum,model,iter,eps,DInitBest);

        NumIters(1,j)=i;
        InitialDesigns(:,:,j)=DInitBest';
        ESsqInits(j)=bestESsq;
        OptDesigns(:,:,j)=DCurr';
        OptESsqs(j)=ESsq;

        min(OptESsqs(OptESsqs > 0))

    end;

    tElapsed=toc/60;

    [BestESsqUnbalanced,BestRun]=min(OptESsqs);
    BestDesign=OptDesigns(:,:,BestRun)';

    BestDesign
    BestESsqUnbalanced

    name=sprintf('n%d_k%d_ESsq_unbalanced_withIntercept_%d',N,NumFactors,NumRuns);

    % save all variables currently in the Matlab environment
    %   * filename will be according to the name indicated
    %   above
    %   * use the command 'load <name>' to bring them back in
    %   * if you don't want any previously existing variables saved
    %        as well, use 'clear all' before calling this script
    save(name)    
    
    % output a text file with just BestDesign

    outfile=sprintf('n%d_k%d_ESsq_unbalanced_withIntercept_%d_just_design.txt',N,NumFactors,NumRuns);

    fileID2=fopen(outfile,'wt');

        formatSpec2=[repmat('%d\t',1,NumFactors),'\n'];
        fprintf(fileID2,formatSpec2,BestDesign');

    fclose(fileID2);
end

