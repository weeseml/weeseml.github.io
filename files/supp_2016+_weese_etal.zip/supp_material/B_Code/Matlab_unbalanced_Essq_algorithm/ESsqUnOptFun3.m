function [Ex,NewCoord,ESsqNew,ESNew,MCurr]=ESsqUnOptFun3(xi,xij,m,MCurr,ESsq,ES)
% Function which takes a current coordinate in the design (xij) and finds the
% exchange that will most decrease the ESsq value, regardless of design
% balance.

    NumFactors=length(xi);

    %%% This is Essq, which will be
    %%% updated as we go through the grid points and find that a potential
    %%% exchange will increase the criterion
    ESsqNew=ESsq;
    ESNew=ES;
    
    Ex=0; % set this to zero; it will be changed if there is an exchange that results in an improvement
    
    % Since we are considering only two level designs, just multiply the
    % current coordinate by -1
    xtry=xi;
    xtry(m)=xij*(-1);  % 'xtry' is the design point that would result if the m'th coordinate is exchanged
    
    % update information matrix
    [ESsqChange,newMm,changes]=ESsqUpdateFun(MCurr,m,xi);
    changes(m+1)=[];
    ESChange=sum(changes)/((NumFactors*(NumFactors+1))/2);
    
    if ESsqChange < 0
        ESsqNew=ESsq + ESsqChange;
        ESNew=ES+ESChange;
        MCurr(m+1,:)=newMm;
        MCurr(:,m+1)=newMm';
        Ex=1;
        NewCoord=xtry(m);
    else
        NewCoord=xij;
    end

    
end